<!-- <div class="banner">



    <div class="banner-img">



        <img src="../images/home/banner1.png" class="img-fluid my_about_slider">



    </div>







</div> -->

<div class="gal-banner">



    <div class="container">
        <div class="col-12">
            <h1 class="gal-banner-title">Contact Us</h1>
            <nav aria-label="breadcrumb">
                <ol class="banner-breadcrumb breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                </ol>
            </nav>
        </div>
    </div>







</div>


<div class="contact-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-12 col-sm-12 col-12 order-lg-2">
                <div class="contact-info-section">

                        <h3 class="vertex-title mb-4">Get In Touch</h3>
                        <div class="d-flex  mb-4">
                            <div>
                            <div class="contact-icon">
                            <img src="../images/contact/cphone.png" class="img-fluid" alt="">
                            </div>
                            </div>
                            <div class="contact-info ml-4 mt-1">
                            <h5 class="mb-1">Phone</h5>
                            <p class="vertex-para vertex-contact-para mb-0"><a href="tel:09- 777 276 277" class="text-white">09- 777 276 277</a>, <a href="tel:09- 777 276 377" class="text-white">09- 777 276 377</a></p>
                            </div>
                            
                        </div>
                         <div class="d-flex  mb-4">
                            <div>
                            <div class="contact-icon">
                            <img src="../images/contact/caddress.png" class="img-fluid" alt="">
                            </div>
                            </div>
                            <div class="contact-info ml-4 mt-1">
                            <h5 class="mb-1">Address</h5>
                            <p class="vertex-para vertex-contact-para mb-0">No. 699, Maha Bandoola Road, 29 Ward, North Dagon Township, Yangon, Myanmar</p>
                            </div>
                            
                        </div>
                        <div class="d-flex">
                            <div>
                            <div class="contact-icon">
                            <img src="../images/contact/cmail.png" class="img-fluid" alt="">
                            </div>
                            </div>
                            <div class="contact-info ml-4 mt-1">
                            <h5 class="mb-1">Email</h5>
                            <p class="vertex-para vertex-contact-para mb-0"><a href="mailto:7vertexmm@gmail.com" class="text-white">7vertexmm@gmail.com</a></p>
                            </div>
                            
                        </div>


                </div>
                <div class="follow-us"><h5 class="footer-title mt-1">Follow Us</h5>
                <p class="text-white mx-3 mb-0 ">-</p>
                <div class="d-flex">
                    <div class="mr-3">
                        <img src="../images/contact/follow-fb.png" class="img-fluid" alt="">
                    </div>
                    <div class="mr-3">
                        <img src="../images/contact/follow-viber.png" class="img-fluid" alt="">
                    </div>
                    <div>
                        <img src="../images/contact/follow-tg.png" class="img-fluid" alt="">
                    </div>
                </div></div>
                
            </div>
             <div class="col-lg-7 col-md-12 col-sm-12 col-12 order-lg-1">
            <div class="send-us-message">
                  <div class="form-section">

                        



                        <h3 class="vertex-title">Send Us A Message</h3>

                        <form class="form-horizontal contactus-form mt-4" action="/contact-us/" role="form" method="post" id="contact-form">

                            <?php

                            $sitekey = '6LffW38rAAAAAFL_YX_QgxvrGQ2_gaq6sMoQWvxq';

                            $secretkey = '6LffW38rAAAAAOfE-_Hb5NoyGKJSGFDWMzuR-vLP';

                            if (isset($_POST['submitted'])) {



                                $yourname = $_POST['yourname'];

                                $email = $_POST['email'];

                                $phone = $_POST['phone'];

                                $subject = $_POST['subject'];



                                $message = $_POST['message'];

                                $captcha = $_POST['g-recaptcha-response'];

                                $date = date("j F, Y, g:i a");

                                $ip = $_SERVER['REMOTE_ADDR'];





                                if (isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])) {



                                    // Google reCAPTCHA verification API Request  

                                    $api_url = 'https://www.google.com/recaptcha/api/siteverify';

                                    $resq_data = array(

                                        'secret' => $secretkey,

                                        'response' => $_POST['g-recaptcha-response'],

                                        'remoteip' => $_SERVER['REMOTE_ADDR']

                                    );



                                    $curlConfig = array(

                                        CURLOPT_URL => $api_url,

                                        CURLOPT_POST => true,

                                        CURLOPT_RETURNTRANSFER => true,

                                        CURLOPT_POSTFIELDS => $resq_data

                                    );



                                    $ch = curl_init();

                                    curl_setopt_array($ch, $curlConfig);

                                    $response = curl_exec($ch);

                                    curl_close($ch);



                                    // Decode JSON data of API response in the array  

                                    $responseData = json_decode($response);





                                    // If the reCAPTCHA API response is valid execute the code to send emails

                                    if ($responseData->success) {



                                        if ($yourname == NULL or $email == NULL or $phone == NULL) {

                                            echo '<div class="alert alert-danger">One or more required fields were left blank. Please fill them in and try again.</div>';

                                            // form($yourname, $email, $phone, $subject, $business, $service, $message);

                                        } else {



                                            $site_name = 'Migrate.me Co.,Ltd';

                                            $headers[] =  'MIME-Version: 1.0';

                                            $headers[] = 'Content-type: text/html; charset=iso-8859-1';

                                            $headers[] = 'From: info@migrateme.com';

                                            $to = "migrateme2022@gmail.com";



                                            $body = 'Hello, <br><br>

                                            You have received the message at ' . $site_name . '. <br><br>                        

                                                                

                                           

                                            

                                            Name: ' . $yourname . '<br/><br/>

                                            Email: ' . $email . '<br><br>

                                            Phone: ' . $phone . '<br><br>

                                            Subject: ' . $subject . '<br><br>

                                            Message: ' . $message;



                                            mail($to, $site_name . " Website Message ", $body, implode("\r\n", $headers));



                                            echo '<div class="alert alert-success"><strong>Thank you very much for contacting us.</strong></div>';

                                        }

                                    } else {

                                        echo "<div class='alert alert-danger'>Recaptcha Verification Not Working!</div>";

                                    }

                                }

                            }

                            ?>

                            <div class="form-content">






                                  <div class="form-group row form-group-mb">



                                    <div class="col-sm-6 col-md-6 col-xs-12 name-column">

                                        <label for="Name" class="contact-label">Name*</label>

                                        <div class="input-group xs-margin">

                                            

                                            <input class="form-control reservation-form-control" id="yourname" placeholder="Your Name" name="yourname"  type="text" required autocomplete="off">



                                        </div>



                                    </div>



                                    <div class="col-sm-6 col-md-6 col-xs-12">

                                        <label for="Phone" class="contact-label">Email*</label>

                                        <div class="input-group input-group-xs-view">



                                            <input class="form-control reservation-form-control" id="email" placeholder="Example@gmail.com" name="email"  type="email" required autocomplete="off">



                                        </div>



                                    </div>



                                </div>



                                <div class="form-group row  form-group-mb">

                                    <div class="col-sm-12 col-md-12 col-xs-12">

                                        <label for="Subject" class="contact-label">Subject*</label>

                                        <div class="input-group input-group-xs-view">



                                            <input class="form-control reservation-form-control" id="subject" placeholder="Title" name="subject"   type="text" autocomplete="off">



                                        </div>



                                    </div>



                                </div>



                                <div class="form-group row aos-init aos-animate">



                                    <div class="col-sm-12 col-md-12 col-xs-12">

                                        <label for="Message" class="contact-label">Message*</label>

                                        <div class="input-group">



                                            <textarea rows="6" class="form-control reservation-form-control" placeholder="Type here..." name="message" id="message" ></textarea>



                                        </div>



                                    </div>



                                </div>



                                <div class="clearfix row">



                                    <div class="col-md-12 col-sm-12 col-xs-12">



                                        <input type="hidden" name="submitted" value="submitted" />



                                        <button type="submit" class="g-recaptcha btn btn-default vertex-white-btn mb-0" data-aos="fade-left" data-sitekey="6LffW38rAAAAAFL_YX_QgxvrGQ2_gaq6sMoQWvxq" data-callback="onSubmit" data-action="submit">

                                            Send Message <img src="../images/contact/yellow-arrow.png" class="img-fluid ml-2" alt="">

                                        </button>

                                        <!-- <span class="arrow-icon ml-2"><i class="fas fa-chevron-right"></i></span> -->





                                    </div>



                                </div>



                            </div>



                        </form>







                    </div>
            </div>
            </div>
        </div>
    </div>
</div>
<div class="map-section">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3818.1290615980824!2d96.19705484681238!3d16.86950897623319!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c19315f850909f%3A0xaef6818b55eda99f!2s7%20VERTEX!5e0!3m2!1sen!2smm!4v1756192973015!5m2!1sen!2smm" width="100%" height="471" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
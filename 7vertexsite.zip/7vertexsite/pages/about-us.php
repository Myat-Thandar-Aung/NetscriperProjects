<!-- <div class="banner">



    <div class="banner-img">



        <img src="../images/home/banner1.png" class="img-fluid my_about_slider">



    </div>







</div> -->

<div class="gal-banner">



    <div class="container">
        <div class="col-12">
            <h1 class="gal-banner-title">About Us</h1>
            <nav aria-label="breadcrumb">
                <ol class="banner-breadcrumb breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">About Us</li>
                </ol>
            </nav>
        </div>
    </div>







</div>



<div class="about-first-section">







    <div class="container">

        <div class="row">
            
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 order-lg-2">



                <h5 class="abt-subtitle">About Us</h5>

                <h2 class="innovate-title">Innovating the Future of Real Estate & Construction</h2>

                <p class="vertex-para">We are one of Myanmar’s most trusted construction companies, building with precision and passion. For decades, we’ve shaped skylines with luxury landmarks and modern spaces that inspire trust, comfort, and pride.</p>

                <div class="d-flex justify-content-center abt-img-top">

                    <img src="../images/about/abt2.png" class="img-fluid" alt="">

                </div>



            </div>

             <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 order-lg-1">



                <div class="d-flex justify-content-center mb-5">



                    <img src="../images/about/abt1.png" class="img-fluid abt1-img" alt="">



                </div>



                <p class="vertex-para">At 7Vertex, we shape spaces and build futures. As a trusted name in real estate and construction, we offer complete solutions — from property development and construction to design and project management. With a focus on quality, integrity, and timely delivery, our skilled team turns your vision into reality for residential, commercial, or investment projects.At 7Vertex, we shape spaces and build futures. As a trusted name in real estate and construction, we offer complete solutions — from property development and construction to design and project management. With a focus on quality, integrity, and timely delivery.</p>

                 <div class="d-flex justify-content-center">



                    <img src="../images/about/abt1.png" class="img-fluid abt2-img" alt="">



                </div>



            </div>
           

        </div>





    </div>



</div>



<div class="about-count-section">

    <div class="container">

        <div class="row">

            <div class="col-lg-3 col-md-6 col-sm-6 col-12">

                <div class="abt-count">

                    <h3 class="text-center">357+</h3>

                    <p class="text-center count-txt mb-0">Project Completed</p>

                </div>

            </div>

            <div class="col-lg-3 col-md-6 col-sm-6 col-12">

                <div class="abt-count">

                    <h3 class="text-center">4+</h3>

                    <p class="text-center count-txt mb-0">Year Experiences</p>

                </div>

            </div>

            <div class="col-lg-3 col-md-6 col-sm-6 col-12">

                <div class="abt-count abt-count-top">

                    <h3 class="text-center">1200K</h3>

                    <p class="text-center count-txt mb-0">Happy Clients</p>

                </div>

            </div>

            <div class="col-lg-3 col-md-6 col-sm-6 col-12">

                <div class="abt-count abt-count-top abt-count-bottom">

                    <h3 class="text-center">68+</h3>

                    <p class="text-center count-txt mb-0">Loyal Partner</p>

                </div>

            </div>

        </div>

    </div>

</div>



<div class="about-first-section">







    <div class="container">

        <div class="row">

            <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12">



                <h5 class="abt-subtitle">Vision, Mission</h5>

                <h2 class="abt-title">Innovating the Future of Real Estate & Construction</h2>


            </div>

            <div class="col-xl-7 col-lg-7 col-md-12 col-sm-12">

                <div class="mvc-section">

                <div class="mvc-flex mb-xl-4 mb-lg-4 mb-4">

                    <div>

                        <div class="mvc-icon">



                            <img src="../images/about/vission.png" class="img-fluid vision-img" alt="">



                        </div>

                    </div>



                    <div class="mvc-content">

                        <h4>Vision</h4>

                        <p class="vertex-para">To become Myanmar’s leading construction brand in the next 10 years — creating sustainable, world-class landmarks that enrich communities and place Myanmar at the forefront of modern architecture in Southeast Asia.</p>

                    </div>

                </div>



                <div class="mvc-flex">

                    <div>

                        <div class="mvc-icon">



                            <img src="../images/about/mission.png" class="img-fluid mission-img" alt="">



                        </div>

                    </div>



                    <div class="mvc-content">

                        <h4 class="mb-3">Mission</h4>

                        <ul class="mission-list pl-2">

                            <li class="mb-2 d-flex align-items-center"><div class="mr-2"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 512 512"><path fill="#e8bc27" d="M17.47 250.9C88.82 328.1 158 397.6 224.5 485.5c72.3-143.8 146.3-288.1 268.4-444.37L460 26.06C356.9 135.4 276.8 238.9 207.2 361.9c-48.4-43.6-126.62-105.3-174.38-137z"/></svg></div>Build with excellence and attention to detail.</li>

                            <li class="mb-2 d-flex align-items-center"><div class="mr-2"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 512 512"><path fill="#e8bc27" d="M17.47 250.9C88.82 328.1 158 397.6 224.5 485.5c72.3-143.8 146.3-288.1 268.4-444.37L460 26.06C356.9 135.4 276.8 238.9 207.2 361.9c-48.4-43.6-126.62-105.3-174.38-137z"/></svg></div>Earn trust through honesty and long-term partnerships.</li>

                            <li class="mb-2 d-flex align-items-center"><div class="mr-2"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 512 512"><path fill="#e8bc27" d="M17.47 250.9C88.82 328.1 158 397.6 224.5 485.5c72.3-143.8 146.3-288.1 268.4-444.37L460 26.06C356.9 135.4 276.8 238.9 207.2 361.9c-48.4-43.6-126.62-105.3-174.38-137z"/></svg></div>Promote green and sustainable design.</li>

                            <li class="mb-2 d-flex align-items-center"><div class="mr-2"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 512 512"><path fill="#e8bc27" d="M17.47 250.9C88.82 328.1 158 397.6 224.5 485.5c72.3-143.8 146.3-288.1 268.4-444.37L460 26.06C356.9 135.4 276.8 238.9 207.2 361.9c-48.4-43.6-126.62-105.3-174.38-137z"/></svg></div>Empower our people and nurture future leaders.</li>

                            <li class="mb-0 d-flex align-items-center"><div class="mr-2"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 512 512"><path fill="#e8bc27" d="M17.47 250.9C88.82 328.1 158 397.6 224.5 485.5c72.3-143.8 146.3-288.1 268.4-444.37L460 26.06C356.9 135.4 276.8 238.9 207.2 361.9c-48.4-43.6-126.62-105.3-174.38-137z"/></svg></div>Shape Myanmar’s skyline with iconic structures.</li>

                        </ul>

                    </div>

                </div>

                </div>

                



            </div>

        </div>





    </div>



</div>



<div class="why-choose-section">



    <div class="container">

        <div class="row">

            <div class="col-12 mb-lg-5 mb-md-5 mb-sm-5 mb-5">

            <h2 class="why-choose-title abt-title mb-2 text-center">Why Choose Us ?</h2>

            <p class="vertex-para text-center mb-0">At 7 VERTEX, we don’t just build structures—we build trust, relationships, and a legacy of quality.</p>

            </div>



            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">

                <div class="why-choose-card">
                <h5 class="mb-3">End-to-End Expertise</h5>
                <div class="d-flex mb-3">
                        <span class="title-bar1"></span>
                        <span class="title-bar1 ml-0"></span>
                        <span class="title-bar2"></span>
                        </div>
                <p class="vertex-para mb-0">From design to handover, we handle every detail.</p>
                </div>

            </div>

            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 col-sm-top">

                <div class="why-choose-card">
                <h5 class="mb-3">Commitment to Quality</h5>
                <div class="d-flex mb-3">
                        <span class="title-bar1"></span>
                        <span class="title-bar1 ml-0"></span>
                        <span class="title-bar2"></span>
                        </div>
                <p class="vertex-para mb-0">Premium materials and strict supervision ensure durability.</p>
                </div>

            </div>

            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 col-xl-top">

                <div class="why-choose-card">
                <h5 class="mb-3">On-Time Delivery</h5>
                <div class="d-flex mb-3">
                        <span class="title-bar1"></span>
                        <span class="title-bar1 ml-0"></span>
                        <span class="title-bar2"></span>
                        </div>
                <p class="vertex-para mb-0">We value your time and keep projects on schedule.</p>
                </div>

            </div>

             <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 col-lg-top">

                <div class="why-choose-card">
                <h5 class="mb-3">Transparent Process</h5>
                <div class="d-flex mb-3">
                        <span class="title-bar1"></span>
                        <span class="title-bar1 ml-0"></span>
                        <span class="title-bar2"></span>
                        </div>
                <p class="vertex-para mb-0">Clear communication and cost control at every step.</p>
                </div>

            </div>

            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 col-lg-top">

                <div class="why-choose-card">
                <h5 class="mb-3">Customer-Centered Approach</h5>
                <div class="d-flex mb-3">
                        <span class="title-bar1"></span>
                        <span class="title-bar1 ml-0"></span>
                        <span class="title-bar2"></span>
                        </div>
                <p class="vertex-para mb-0">We design and build around your needs and lifestyle.</p>
                </div>

            </div>

            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 col-lg-top">

                <div class="why-choose-card">
                <h5 class="mb-3">Our Commitment</h5>
                <div class="d-flex mb-3">
                        <span class="title-bar1"></span>
                        <span class="title-bar1 ml-0"></span>
                        <span class="title-bar2"></span>
                        </div>
                <p class="vertex-para mb-0">Every project we take on is guided by precision, passion, and the pursuit of excellence.</p>
                </div>

            </div>

        

        </div>

    </div>

</div>
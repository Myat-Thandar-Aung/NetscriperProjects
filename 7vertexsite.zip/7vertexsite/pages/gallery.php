<!-- <div class="banner">



    <div class="banner-img">



        <img src="../images/home/banner1.png" class="img-fluid my_about_slider">



    </div>







</div> -->

<div class="gal-banner">

    <div class="container">
        <div class="col-12">
            <h1 class="gal-banner-title">Gallery</h1>
            <nav aria-label="breadcrumb">
                <ol class="banner-breadcrumb breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Gallery</li>
                </ol>
            </nav>
        </div>
    </div>

</div>


<div class="svc-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <!-- <h5 class="abt-subtitle">Construction & Supervision</h5> -->
                <h2 class="innovate-title">Our Gallery</h2>
                <p class="vertex-para mb-0">Welcome to our gallery—a curated collection of moments captured, ideas realized, and beauty crafted. This is more than just a portfolio; it's a narrative of our journey. </p>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-6 col-12 col-lg-top">

                <a href="../images/gallery/gl1.png" data-fancybox="gallery">

                    <div class="gallery-card">



                        <img src="../images/gallery/gal1.png" class="img-fluid" alt="">

                        <div class="overlay gal-overlay">

                            <div class="middle">

                                <div class="d-flex justify-content-center mb-2">

                                    <img src="../images/home/eye.png" class="img- gimg" alt="">

                                </div>

                                <p class="text">View Detail</p>

                            </div>

                        </div>





                    </div>

                </a>


            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12 col-lg-top">

                <a href="../images/gallery/gl2.png" data-fancybox="gallery">

                    <div class="gallery-card">



                        <img src="../images/gallery/gal2.png" class="img-fluid" alt="">

                        <div class="overlay gal-overlay">

                            <div class="middle">

                                <div class="d-flex justify-content-center mb-2">

                                    <img src="../images/home/eye.png" class="img- gimg" alt="">

                                </div>

                                <p class="text">View Detail</p>

                            </div>

                        </div>





                    </div>

                </a>


            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12 col-lg-top">
                <a href="../images/gallery/gal3.png" data-fancybox="gallery">

                    <div class="gallery-card">



                        <img src="../images/gallery/gal3.png" class="img-fluid" alt="">

                        <div class="overlay gal-overlay">

                            <div class="middle">

                                <div class="d-flex justify-content-center mb-2">

                                    <img src="../images/home/eye.png" class="img- gimg" alt="">

                                </div>

                                <p class="text">View Detail</p>

                            </div>

                        </div>





                    </div>

                </a>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12 col-lg-top">
                <a href="../images/gallery/gal4.png" data-fancybox="gallery">

                    <div class="gallery-card">



                        <img src="../images/gallery/gal4.png" class="img-fluid" alt="">

                        <div class="overlay gal-overlay">

                            <div class="middle">

                                <div class="d-flex justify-content-center mb-2">

                                    <img src="../images/home/eye.png" class="img- gimg" alt="">

                                </div>

                                <p class="text">View Detail</p>

                            </div>

                        </div>





                    </div>

                </a>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12 col-lg-top">
                <a href="../images/gallery/gal5.png" data-fancybox="gallery">

                    <div class="gallery-card">



                        <img src="../images/gallery/gal5.png" class="img-fluid" alt="">

                        <div class="overlay gal-overlay">

                            <div class="middle">

                                <div class="d-flex justify-content-center mb-2">

                                    <img src="../images/home/eye.png" class="img- gimg" alt="">

                                </div>

                                <p class="text">View Detail</p>

                            </div>

                        </div>





                    </div>

                </a>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12 col-lg-top">
                <a href="../images/gallery/gal6.png" data-fancybox="gallery">

                    <div class="gallery-card">



                        <img src="../images/gallery/gal6.png" class="img-fluid" alt="">

                        <div class="overlay gal-overlay">

                            <div class="middle">

                                <div class="d-flex justify-content-center mb-2">

                                    <img src="../images/home/eye.png" class="img- gimg" alt="">

                                </div>

                                <p class="text">View Detail</p>

                            </div>

                        </div>





                    </div>

                </a>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12 col-lg-top">
                <a href="../images/gallery/gal3.png" data-fancybox="gallery">

                    <div class="gallery-card">



                        <img src="../images/gallery/gal3.png" class="img-fluid" alt="">

                        <div class="overlay gal-overlay">

                            <div class="middle">

                                <div class="d-flex justify-content-center mb-2">

                                    <img src="../images/home/eye.png" class="img- gimg" alt="">

                                </div>

                                <p class="text">View Detail</p>

                            </div>

                        </div>





                    </div>

                </a>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12 col-lg-top">
                <a href="../images/gallery/gal4.png" data-fancybox="gallery">

                    <div class="gallery-card">



                        <img src="../images/gallery/gal4.png" class="img-fluid" alt="">

                        <div class="overlay gal-overlay">

                            <div class="middle">

                                <div class="d-flex justify-content-center mb-2">

                                    <img src="../images/home/eye.png" class="img- gimg" alt="">

                                </div>

                                <p class="text">View Detail</p>

                            </div>

                        </div>





                    </div>

                </a>
            </div>


        </div>
    </div>
</div>
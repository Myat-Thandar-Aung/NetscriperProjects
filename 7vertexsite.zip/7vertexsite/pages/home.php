<div id="demo" class="carousel slide" data-ride="carousel" data-interval="2000">

    <div class="carousel-inner">

        <div class="carousel-item active">

            <img src="/images/slider/s1.png" class="img-fluid">



        </div>

        <div class="carousel-item">

            <img src="/images/slider/s1.png" class="img-fluid">



        </div>

        <div class="carousel-item">

            <img src="/images/slider/s1.png" class="img-fluid">



        </div>



    </div>

    <a class="carousel-control-prev" href="#demo" data-slide="prev">

        <!-- <span class="carousel-control-prev-icon"></span> -->

        <img src="../images/home/carousel-arrow-left.png" class="img-fluid carousel-arrow-left" alt="">

    </a>

    <a class="carousel-control-next" href="#demo" data-slide="next">

        <!-- <span class="carousel-control-next-icon"></span> -->

        <img src="../images/home/carousel-arrow-right.png" class="img-fluid carousel-arrow-right" alt="">

    </a>

</div>

<div class="h-about-section">



    <div class="container">

        <div class="row align-items-center">

            <div class="col-lg-5 col-md-12 col-sm-12 col-12">
                <a href="/about-us/">
                    <div class="d-flex justify-content-center">

                    <img src="/images/home/abt.png" class="img-fluid habout-img">

                </div>
                </a>
                



            </div>

            <div class="col-lg-7 col-md-12 col-sm-12 col-12">

                <div class="about-section">

                    <div class="d-flex align-items-center">

                        <h3 class="vertex-title mb-3">About Us</h3>



                    </div>



                    <p class="vertex-para">At 7Vertex, we shape spaces and build futures. As a trusted name in real estate and construction, we offer complete solutions — from property development and construction to design and project management. With a focus on quality, integrity, and timely delivery, our skilled team turns your vision into reality for residential, commercial, or investment projects.</p>

                    <div class="row my-lg-4 my-md-5 my-sm-5 my-4">

                        <div class="col-lg-4 col-md-4 col-sm-4 col-12">

                            <div class="abt-count">

                                <h3 class="text-center">4+</h3>

                                <p class="text-center vertex-para mb-0">Year Experiences</p>

                            </div>

                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4 col-12">

                            <div class="abt-count">

                                <h3 class="text-center">357+</h3>

                                <p class="text-center vertex-para mb-0">Project Completed</p>

                            </div>

                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4 col-12">

                            <div class="mb-0 abt-count">

                                <h3 class="text-center">68+</h3>

                                <p class="text-center vertex-para mb-0">Loyal Partner</p>

                            </div>

                        </div>

                    </div>



                    <!-- <div class="habout-img-flex">

                        <img src="/images/home/about.png" class="img-fluid">

                    </div> -->

                    <div class="d-flex read-more-flex">

                        <a href="/about-us/" class="text-decoration-none">

                            <div class="vertex-btn text-center">

                                Read More <img src="../images/logo/arrow.png" class="img-fluid ml-2">

                            </div>

                        </a>

                    </div>



                </div>

            </div>

        </div>

    </div>

</div>

<div class="h-service-section">

    <div class="container">

        <div class="row">

            <div class="col-12">

                <h3 class="vertex-title text-center mb-5">Our Services</h3>

            </div>

            <div class="col-12">

                <div class="owl-carousel owl-theme service-carousel">
                    <a href="/design-and-approval/" class="text-decoration-none">
                         <div class="svc-card">

                        <h5 class="mb-3"><b class="mr-1">01.</b> Design & Approval</h5>

                        <div class="svc-card-flex">

                            <img src="../images/home/svc1.png" class="img-fluid" alt="">

                        </div>

                        <div class="side-arrow">

                            <div>

                                <img src="../images/home/side-arrow.png" class="img-fluid" alt="">

                            </div>



                        </div>

                    </div>
                    </a>
                   
                    <a href="/construction-supervision/" class="text-decoration-none">
                        <div class="svc-card">

                        <h5 class="mb-3"><b class="mr-1">02.</b> Construction & Supervision</h5>

                        <div class="svc-card-flex">

                            <img src="../images/home/svc2.png" class="img-fluid" alt="">

                        </div>

                        <div class="side-arrow">

                            <div>

                                <img src="../images/home/side-arrow.png" class="img-fluid" alt="">

                            </div>



                        </div>

                    </div>
                    </a>
                    
                    <a href="/project-management/" class="text-decoration-none">
                        <div class="svc-card">

                        <h5 class="mb-3"><b class="mr-1">03.</b> Project Management</h5>

                        <div class="svc-card-flex">

                            <img src="../images/home/svc4.png" class="img-fluid" alt="">

                        </div>

                        <div class="side-arrow">

                            <div>

                                <img src="../images/home/side-arrow.png" class="img-fluid" alt="">

                            </div>



                        </div>

                    </div>
                    </a>
                    
                    <a href="/interior-decoration/" class="text-decoration-none">
                         <div class="svc-card">

                        <h5 class="mb-3"><b class="mr-1">04.</b> Interior Decoration</h5>

                        <div class="svc-card-flex">

                            <img src="../images/home/svc3.png" class="img-fluid" alt="">

                        </div>

                        <div class="side-arrow">

                            <div>

                                <img src="../images/home/side-arrow.png" class="img-fluid" alt="">

                            </div>



                        </div>

                    </div>
                    </a>
                   
                    <a href="/renovation-and-remodeling/" class="text-decoration-none">
                        <div class="svc-card">

                        <h5 class="mb-3"><b class="mr-1">05.</b> Renovation & Remodeling</h5>

                        <div class="svc-card-flex">

                            <img src="../images/home/svc5.png" class="img-fluid" alt="">

                        </div>

                        <div class="side-arrow">

                            <div>

                                <img src="../images/home/side-arrow.png" class="img-fluid" alt="">

                            </div>



                        </div>

                    </div>
                    </a>
                    
                    <a href="/real-estate-development/" class="text-decoration-none">
                        <div class="svc-card">

                        <h5 class="mb-3"><b class="mr-1">06.</b> Real Estate Development</h5>

                        <div class="svc-card-flex">

                            <img src="../images/home/svc6.png" class="img-fluid" alt="">

                        </div>

                        <div class="side-arrow">

                            <div>

                                <img src="../images/home/side-arrow.png" class="img-fluid" alt="">

                            </div>



                        </div>

                    </div>
                    </a>
                    



                </div>

            </div>

        </div>

    </div>

</div>

<div class="h-project-section">



    <div class="container">

        <div class="row">

            <div class="col-xl-5 col-lg-12 col-md-12 col-sm-12 col-12">

                <div class="about-right-section">

                    <div class="d-flex align-items-center">

                        <h3 class="vertex-title mb-3">Our Projects</h3>



                    </div>



                    <p class="vertex-para">Discover a curated selection of residential and commercial spaces designed for comfort, style, and lasting value. Whether you’re looking to buy, invest, or develop, 7Vertex offers properties that match your vision and needs.</p>





                </div>

            </div>



            <div class="col-xl-7 col-lg-12 col-md-12 col-sm-12 col-12 our-pj">

               

                    <div class="owl-carousel owl-theme project-carousel">

                        <div class="project-card">

                            <div class="d-flex justify-content-center">

                                <img src="../images/home/pj1.png" class="img-fluid" alt="">

                            </div>

                            <div class="project-card-caption">

                                <p class="text-white mb-0 pt-3">Residential & Commercial<br class="br-md"> Apartments</p>

                                <div class="pt-3">

                                    <img src="../images/home/pj-arrow.png" class="img-fluid" alt="">

                                </div>

                            </div>

                        </div>

                        <div class="project-card">

                            <div class="d-flex justify-content-center">

                                <img src="../images/home/pj2.png" class="img-fluid" alt="">

                            </div>

                            <div class="project-card-caption">

                                <p class="text-white mb-0 pt-3">Condominium</p>

                                <div class="pt-3">

                                    <img src="../images/home/pj-arrow.png" class="img-fluid" alt="">

                                </div>

                            </div>

                        </div>

                        <div class="project-card">

                            <div class="d-flex justify-content-center">

                                <img src="../images/home/pj3.png" class="img-fluid" alt="">

                            </div>

                            <div class="project-card-caption">

                                <p class="text-white mb-0 pt-3">Villa</p>

                                <div class="pt-3">

                                    <img src="../images/home/pj-arrow.png" class="img-fluid" alt="">

                                </div>

                            </div>



                        </div>



                        <div class="project-card">

                            <div class="d-flex justify-content-center">

                                <img src="../images/home/pj2.png" class="img-fluid" alt="">

                            </div>

                            <div class="project-card-caption">

                                <p class="text-white mb-0 pt-3">Residential & Commercial<br class="br-md"> Apartments</p>

                                <div class="pt-3">

                                    <img src="../images/home/pj-arrow.png" class="img-fluid" alt="">

                                </div>

                            </div>

                        </div>

                        <div class="project-card">

                            <div class="d-flex justify-content-center">

                                <img src="../images/home/pj1.png" class="img-fluid" alt="">

                            </div>

                            <div class="project-card-caption">

                                <p class="text-white mb-0 pt-3">Villa</p>

                                <div class="pt-3">

                                    <img src="../images/home/pj-arrow.png" class="img-fluid" alt="">

                                </div>

                            </div>

                        </div>

                    </div>

             





            </div>



        </div>

    </div>





</div>

<div class="h-service-section">

    <div class="container">

        <div class="row">

            <div class="col-12">

                <h3 class="vertex-title text-center mb-5">Our testimonials</h3>

            </div>

            <div class="col-12">

                <div class="owl-carousel owl-theme testimonial-carousel">

                    <div class="testimonial-card">

                        <div class="testimonial-block">

                            <p class="vertex-para text-white">

                                7Vertex turned our dream home into reality. The team was professional, attentive, and delivered exactly what we envisioned — on time and within budget

                            </p>

                            <div class="commenter">

                                <div class="quote mr-3">

                                    <img src="../images/home/quote.png" class="img-fluid" alt="">

                                </div>

                                <div class="commentor-name">

                                    <h5 class="mb-1">Daw May Thin</h5>

                                    <p class="mb-0">Homeowner</p>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="testimonial-card">

                        <div class="testimonial-block">

                            <p class="vertex-para text-white">

                                From design to completion, 7Vertex managed our office construction seamlessly. Their quality workmanship and clear communication set them apart.

                            </p>

                            <div class="commenter">

                                <div class="quote mr-3">

                                    <img src="../images/home/quote.png" class="img-fluid" alt="">

                                </div>

                                <div class="commentor-name">

                                    <h5 class="mb-1">Ko Aung Min</h5>

                                    <p class="mb-0">Business Owner</p>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="testimonial-card">

                        <div class="testimonial-block">

                            <p class="vertex-para text-white">

                                7Vertex turned our dream home into reality. The team was professional, attentive, and delivered exactly what we envisioned — on time and within budget

                            </p>

                            <div class="commenter">

                                <div class="quote mr-3">

                                    <img src="../images/home/quote.png" class="img-fluid" alt="">

                                </div>

                                <div class="commentor-name">

                                    <h5 class="mb-1">Mr. James Tan</h5>

                                    <p class="mb-0">Real Estate Investor</p>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="testimonial-card">

                        <div class="testimonial-block">

                            <p class="vertex-para text-white">

                                From design to completion, 7Vertex managed our office construction seamlessly. Their quality workmanship and clear communication set them apart.

                            </p>

                            <div class="commenter">

                                <div class="quote mr-3">

                                    <img src="../images/home/quote.png" class="img-fluid" alt="">

                                </div>

                                <div class="commentor-name">

                                    <h5 class="mb-1">Ko Aung Min</h5>

                                    <p class="mb-0">Business Owner</p>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="testimonial-card">

                        <div class="testimonial-block">

                            <p class="vertex-para text-white">

                                7Vertex turned our dream home into reality. The team was professional, attentive, and delivered exactly what we envisioned — on time and within budget

                            </p>

                            <div class="commenter">

                                <div class="quote mr-3">

                                    <img src="../images/home/quote.png" class="img-fluid" alt="">

                                </div>

                                <div class="commentor-name">

                                    <h5 class="mb-1">Mr. James Tan</h5>

                                    <p class="mb-0">Real Estate Investor</p>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="testimonial-card">

                        <div class="testimonial-block">

                            <p class="vertex-para text-white">

                                From design to completion, 7Vertex managed our office construction seamlessly. Their quality workmanship and clear communication set them apart.

                            </p>

                            <div class="commenter">

                                <div class="quote mr-3">

                                    <img src="../images/home/quote.png" class="img-fluid" alt="">

                                </div>

                                <div class="commentor-name">

                                    <h5 class="mb-1">Ko Aung Min</h5>

                                    <p class="mb-0">Business Owner</p>

                                </div>

                            </div>

                        </div>

                    </div>



                </div>

            </div>

        </div>

    </div>

</div>

<div class="h-about-section">



    <div class="container">

        <div class="row align-items-center">

            <div class="col-12">

                <h3 class="vertex-title text-center">Our GalLery</h3>

            </div>

            <div class="col-12">

                <div class="owl-carousel owl-theme gallery-carousel">

                    <a href="../images/home/glg1.png" data-fancybox="gallery">

                    <div class="gallery-card">



                        <img src="../images/home/g1.png" class="img-fluid" alt="">

                        <div class="overlay">

                        <div class="middle">

                            <div class="d-flex justify-content-center mb-2">

                                <img src="../images/home/eye.png" class="img-fluid gimg" alt="">

                            </div>

                            <p class="text">View Detail</p>

                        </div>

                        </div>

                    



                    </div>

                    </a>

                    <a href="../images/home/glg2.png" data-fancybox="gallery">

                        <div class="gallery-card">



                        <img src="../images/home/g2.png" class="img-fluid" alt="">

                        <div class="overlay">

                        <div class="middle">

                            <div class="d-flex justify-content-center mb-2">

                                <img src="../images/home/eye.png" class="img-fluid gimg" alt="">

                            </div>

                            <p class="text">View Detail</p>

                        </div>

                        </div>



                    </div>

                    </a>



                    <a href="../images/home/glg3.png" data-fancybox="gallery">

                        <div class="gallery-card">



                        <img src="../images/home/g3.png" class="img-fluid" alt="">

                        <div class="overlay">

                        <div class="middle">

                            <div class="d-flex justify-content-center mb-2">

                                <img src="../images/home/eye.png" class="img-fluid gimg" alt="">

                            </div>

                            <p class="text">View Detail</p>

                        </div>

                        </div>



                    </div>

                    </a>



                    <a href="../images/home/glg1.png" data-fancybox="gallery">

                        <div class="gallery-card">



                        <img src="../images/home/g1.png" class="img-fluid" alt="">

                        <div class="overlay">

                        <div class="middle">

                            <div class="d-flex justify-content-center mb-2">

                                <img src="../images/home/eye.png" class="img-fluid gimg" alt="">

                            </div>

                            <p class="text">View Detail</p>

                        </div>

                        </div>



                    </div>

                    </a>

                

                    <a href="../images/home/glg2.png" data-fancybox="gallery">

                        <div class="gallery-card">



                        <img src="../images/home/g2.png" class="img-fluid" alt="">

                        <div class="overlay">

                        <div class="middle">

                            <div class="d-flex justify-content-center mb-2">

                                <img src="../images/home/eye.png" class="img-fluid gimg" alt="">

                            </div>

                            <p class="text">View Detail</p>

                        </div>

                        </div>



                    </div>

                    </a>

                    

                    <a href="../images/home/glg3.png" data-fancybox="gallery">

                        <div class="gallery-card">



                        <img src="../images/home/g3.png" class="img-fluid" alt="">

                        <div class="overlay">

                        <div class="middle">

                            <div class="d-flex justify-content-center mb-2">

                                <img src="../images/home/eye.png" class="img-fluid gimg" alt="">

                            </div>

                            <p class="text">View Detail</p>

                        </div>

                        </div>



                    </div>

                    </a>

                    

                </div>

            </div>

        </div>

    </div>

</div>
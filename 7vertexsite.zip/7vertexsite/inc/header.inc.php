<?php ob_start();

?>

<!DOCTYPE html>

<html>



<head>

	<?php

	if (isset($_REQUEST['pg'])) {

		$page = $_REQUEST['pg'];

	} else {

		$page = NULL;

	}



	if ($page <> NULL) {

		$seo_titile = str_replace("-", " ", $page);

	?>

		<title><?php echo ucwords($seo_titile); ?> | 7 Vertex Co.,Ltd </title>

		<meta name="description" content="<?php echo ucwords($seo_titile);?>, We are one of Myanmar’s most trusted construction companies, building with precision and passion." />

		<!-- <meta name="description" content="<?php echo ucwords($seo_titile); ?>, " /> -->

	<?php } else { ?>

		<title>7 Vertex Co.,Ltd </title>

		<meta name="description" content="From concept to clearance, we turn your vision into an approved reality. Our expert architects and engineers craft detailed designs, prepare all technical documents, and handle regulatory approvals—so your dream project moves forward without delays." />

		<!-- <meta name="description" content="" /> -->

	<?php }

	?>



	<title> 7 Vertex Co.,Ltd </title>

	<meta charset="utf-8">



	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<meta name="viewport" content="width=device-width, initial-scale=1">



	<!-- ...icon... -->

	<link rel="icon" href="/images/logo/sm-logo.png" type="image/x-icon">



	<!-- .......bootstrapt link....... -->

	<link rel="stylesheet" href="/css/bootstrap.min.css">



	<!-- ........font....... -->

	<link rel="stylesheet" href="/font-awesome/css/fontawesome.min.css">

	<link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,opsz,wght@0,18..144,300..900;1,18..144,300..900&family=Public+Sans:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

	<!-- <link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Merriweather:ital,opsz,wght@0,18..144,300..900;1,18..144,300..900&family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet"> -->

	



	<!-- ........owl carousel.......... -->

	<link rel="stylesheet" href="/css/owl.carousel.min.css">

	<link rel="stylesheet" href="/css/owl.theme.default.min.css">



	<link rel="stylesheet" href="/css/jquery.fancybox.css" />





	<!-- ..........menu........... -->

	<link rel="stylesheet" href="/css/mmenu.css">

	<link rel="stylesheet" href="/css/hamburgers.css">

	<link rel="stylesheet" href="/css/mmenu-style.css">



	 <link rel="stylesheet" href='https://mmwebfonts.comquas.com/fonts/?font=oursunicode' />



	<!-- .......css link........ -->

	<link rel="stylesheet" type="text/css" href="/css/style.css">



	<!-- .........imagehover.css......... -->

	<link rel="stylesheet" href="/css/imagehover.css">

	<link rel="stylesheet" href="/css/imagehover.min.css">





	<script src="https://www.google.com/recaptcha/api.js"></script>



</head>



<body>
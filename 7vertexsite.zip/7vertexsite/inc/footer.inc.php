

	</div>

	<div id="go-top" class="scrollTop">

	<i class="fa fa-angle-up" aria-hidden="true"></i>

	</div>

	<footer>

			<div class="first-section">

			<div class="container">

				<div class="row">

					<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">

					

							

						

								<h5 class="footer-title mb-lg-3">Contact Info</h5>

								<div class="d-flex">

									<div class="d-flex ftr-icon">

										<div><img src="../images/home/map.png" class="img-fluid" alt=""></div>

										<p class="ftr-title ml-2 mb-0">Address</p>

									</div>

									<div class="ftr-para mt-1">

										<p class="vertex-para mb-1">No. 699, Maha Bandoola Road, 29 Ward, North Dagon Township, Yangon, Myanmar</p>

									</div>

								</div>

								<div class="d-flex">

									<div class="d-flex ftr-icon">

										<div><img src="../images/home/phone.png" class="img-fluid" alt=""></div>

										<p class="ftr-title ml-2 mb-0">Phone</p>

									</div>

									<div class="ftr-para mt-1">

										<p class="vertex-para mb-1"><a href="tel:09- 777 276 277" class="text-white text-decoration-none">09- 777 276 277</a>,<a href="tel:09- 777 276 377" class="text-white text-decoration-none ml-2">09- 777 276 377</a></p>

									</div>

								</div>

								<div class="d-flex">

									<div class="d-flex ftr-icon">

										<div><img src="../images/home/mail.png" class="img-fluid" alt=""></div>

										<p class="ftr-title ml-2 mb-0">Email</p>

									</div>

									<div class="ftr-para mt-1">

										<p class="vertex-para"><a href="mailto:7vertexmm@gmail.com" class="text-white text-decoration-none">7vertexmm@gmail.com</a></p>

									</div>

								</div>

							

							

							

					</div>

					<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">

						<h5 class="footer-title mb-lg-3 footer-service-title">Our Services</h5>

						<ul class="ftr-svc-lst pl-3">

							<li class="mb-2"><a href="/design-and-approval/" class="text-decoration-none">Design & Approval </a></li>

							<li class="mb-2"><a href="/construction-supervision/" class="text-decoration-none">Construction & Supervision</a></li>

							<li class="mb-2"><a href="/project-management/" class="text-decoration-none">Project Management</a></li>

							<li class="mb-0"><a href="/interior-decoration/" class="text-decoration-none">Interior Decoration</a></li>

							<li class="mb-0"><a href="/renovation-and-remodeling/" class="text-decoration-none">Renovation & Remodeling</a></li>

							<li class="mb-0"><a href="/real-estate-development/" class="text-decoration-none">Real Estate Development</a></li>

						</ul>

						

					</div>

					<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">

						<div class="d-flex justify-content-end footer-products">

						<div>

						<h5 class="footer-title mb-lg-3">Follow Us</h5>

						<div class="d-flex">

							<div class="mr-3">

								<img src="../images/home/fb.png" class="img-fluid" alt="">

							</div>

							<div class="mr-3">

								<img src="../images/home/viber.png" class="img-fluid" alt="">

							</div>

							<div>

								<img src="../images/home/telegram.png" class="img-fluid" alt="">

							</div>

						</div>

						</div>

						

						</div>

						

						

					</div>

				</div>

			</div>

			</div>

			

	

		<div class="second-section">

			<div class="container">

				<div class="row">

					<div class="col-lg-12">

						<hr class="copy-hr mb-2">

						<div class="copy-text">

							<p  class="text-center mb-0">© 2025 7 Vertex. All Rights Reserved. Web Designed by <a href="https://www.netscriper.com/" class="text-white">NetScriper</a>.</p>

						</div>

					</div>

				</div>

			</div>

		</div>

	</footer>

	

	<!-- ...........................javascript.............................. -->

	<script src="https://kit.fontawesome.com/e4d2fbad5e.js" crossorigin="anonymous"></script>

	<script src="/js/jquery.min.js"></script>

    <script src="/js/bootstrap.min.js"></script>

    <script src="/js/owl.carousel.js"></script>

	<script src="/js/jquery.fancybox.min.js"></script>

	<script src="/js/mmenu.js"></script>

    <script src="/js/mmenu-script.js"></script>

    <script src="/js/javascript.js"></script>

	<script src="/js/contact.js"></script>

	<script src="https://code.iconify.design/iconify-icon/1.0.8/iconify-icon.min.js"></script>

	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-121449263-17"></script>



</body>

</html>
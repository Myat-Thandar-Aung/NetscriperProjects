	<div id="background">

		<header>

			<div class="nav-background">

				<div class="nav-head">

				<div class="container-fluid">

					<div class="row align-items-center">

						<div class="col-xl-3 col-lg-2 col-sm-10 col-10">

						<a href="/">

							<div  class="logo d-flex align-items-center">

								<img src="/images/logo/seven-vertex-logo.png" alt="..." class="img-fluid">

								

								

							</div>

							</a>

						</div>



						<div class="col-xl-9 col-lg-10 col-sm-2 col-2 ">



							<nav class="navbar navbar-expand-lg navbar-light ">

								<div class="fixed visible-xs hidden-md">

									<button id="my-icon" class="navbar-toggle collapsed hamburger hamburger--spin" type="button">

										<span class="hamburger-box">

											<span class="hamburger-inner"></span> 

										</span>

									</button>

								</div>	

								<div class="collapse navbar-collapse" id="navbarNavDropdown">

									<ul class="navbar-nav">	

										<li class="nav-item <?php if($page=="" || $page==NULL || $page=="home"){echo ' active';}?>">

											<a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>

										</li>

										<li class="nav-item  <?php if($page=="about-us"){echo ' active';}?>">

											<a class="nav-link" href="/about-us/">About Us</a>

										</li>

										

										 <li class="nav-item nav-item-right dropdown productlink <?php if (($page == "design-and-approval") || ($page == "construction-supervision") || ($page == "project-management") || ($page == "interior-decoration") || ($page == "renovation-and-remodeling") || ($page == "real-estate-development"))  {



                                                                                echo ' active';



                                                                            } ?>">

                                             <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Our Services

                                                

                                             </a>



                                             <div class="dropdown-menu dragondropdown" aria-labelledby="navbarDropdownMenuLink">

                                                <a class="dropdown-item <?php if ($page == "design-and-approval") {



                                                                                echo ' active';



                                                                            } ?>" href="/design-and-approval/">Design & Approval</a>

                                                <a class="dropdown-item <?php if ($page == "construction-supervision") {



                                                                                echo ' active';



                                                                            } ?>" href="/construction-supervision/">Construction & Supervision</a>
												<a class="dropdown-item <?php if ($page == "project-management") {



                                                                                echo ' active';



                                                                            } ?>" href="/project-management/">Project Management</a>
												<a class="dropdown-item <?php if ($page == "interior-decoration") {



                                                                                echo ' active';



                                                                            } ?>" href="/interior-decoration/">Interior Decoration</a>
												<a class="dropdown-item <?php if ($page == "renovation-and-remodeling") {



                                                                                echo ' active';



                                                                            } ?>" href="/renovation-and-remodeling/">Renovation & Remodeling</a>
												<a class="dropdown-item <?php if ($page == "real-estate-development") {



                                                                                echo ' active';



                                                                            } ?>" href="/real-estate-development/">Real Estate Development</a>

                                               

                                             </div>

                                         </li>



										<li class="nav-item  <?php if($page=="our-projects"){echo ' active';}?>">

											<a class="nav-link" href="/our-projects/" disabled>Our Projects</a>

										</li>



										<li class="nav-item  <?php if($page=="gallery"){echo ' active';}?>">

											<a class="nav-link" href="/gallery/">Gallery</a>

										</li>



										<li class="nav-item  <?php if($page=="contact-us"){echo ' active';}?> latest">

											<a class="nav-link vertex-btn" href="/contact-us/">

												<img src="../images/logo/headphone.png" class="img-fluid mr-2 headphone" alt="">

												Contact Us

											</a>

										</li>

									</ul>

								</div>

							</nav>

						</div>

						<!-- <div class="col-lg-8 col-sm-2 col-xs-12 ">



							<nav class="navbar navbar-expand-lg navbar-light ">

								<div class="fixed visible-xs hidden-md">

									<button id="my-icon" class="navbar-toggle collapsed hamburger hamburger--spin" type="button">

										<span class="hamburger-box">

											<span class="hamburger-inner"></span> 

										</span>

									</button>

								</div>	

								<div class="collapse navbar-collapse" id="navbarNavDropdown">

									<ul class="navbar-nav">	

										<li class="nav-item <?php if($page=="" || $page==NULL || $page=="home"){echo ' active';}?>">

											<a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>

										</li>

										<li class="nav-item  <?php if($page=="about-us"){echo ' active';}?>">

											<a class="nav-link" href="/about-us/">About Us</a>

										</li>

										

										 <li class="nav-item nav-item-right dropdown productlink">

                                             <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Products

                                                

                                             </a>



                                             <div class="dropdown-menu dragondropdown" aria-labelledby="navbarDropdownMenuLink">

                                                <a class="dropdown-item" href="/bread/">Bread</a>

                                                 <a class="dropdown-item" href="/snack/">Snack</a>

                                               

                                             </div>

                                         </li>



										<li class="nav-item  <?php if($page=="careers"){echo ' active';}?>">

											<a class="nav-link" href="/careers/">Careers</a>

										</li>



										<li class="nav-item  <?php if($page=="contact-us"){echo ' active';}?> latest">

											<a class="nav-link" href="/contact-us/">Contact Us</a>

										</li>

									</ul>

								</div>

							</nav>

						</div>					 -->

					</div>

				</div>

				</div>

				

			</div>

		</header>

	</div>



	<div class="pages-content">
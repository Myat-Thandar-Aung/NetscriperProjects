$(".service-carousel").owlCarousel({

  loop: true,

  margin: 15,

  nav: false,

  dots: false,

  autoplay: false,

  // autoplayTimeOut: 2000,

  responsive: {

    0: {

      items: 1,

    },

    576: {

      items: 1,

    },

    768: {

      items: 2,

    },

    992: {

      items: 3,

    },

    1200: {

      items: 4,

    },

    1325: {
      items: 4,
    },

    1400: {

      items: 4,

    },

  },

});



$(".testimonial-carousel").owlCarousel({

  loop: true,

  margin: 15,

  nav: false,

  dots: true,

  autoplay: false,

  // autoplayTimeOut: 1000,

  responsive: {

    0: {

      items: 1,

    },

    768: {

      items: 1,

    },

    992: {

      items: 2,

    },

    1200: {

      items: 3,

    },

    1700: {

      items: 3,

    },

  },

});



$(".gallery-carousel").owlCarousel({

  loop: true,

  margin: 15,

  nav: true,

  navText: ['<img src="../images/home/lft-arrow.png" class="img-fluid">','<img src="../images/home/rght-arrow.png" class="img-fluid">'],

  dots: false,

  autoplay: false,

  // autoplayTimeOut: 2000,

  responsive: {

    0: {

      items: 1,

    },

    500: {

      items: 2,

    },

    576: {

      items: 2,

    },

    768: {

      items: 2,

    },

    992: {

      items: 3,

    },

    1200: {

      items: 3,

    },

    1700: {

      items: 3,

    },

  },

});



$(".project-carousel").owlCarousel({
  items: 2.5,
  responsiveRefreshRate: 100,
  loop: true,

  margin: 20,

  nav: true,

  navText: ['<img src="../images/home/lft-arrow.png" class="img-fluid">','<img src="../images/home/rght-arrow.png" class="img-fluid">'],

  dots: false,

  autoplay: false,

  // autoplayTimeOut: 1000,

  responsive: {

    0: {

      items: 1,

    },

    576: {

      items: 1,

    },

    768: {

      items: 2,

    },

    992: {

      items: 2,

    },

    1200: {

      items: 2,

    },

    1400: {

      items: 2,

    },

    1700: {

      items: 2.5,

    },

  },

});



$(document).ready(function () {

  $("#go-top").hide();

  $(window).scroll(function () {

    if ($(this).scrollTop() > 100) {

      $("#go-top").fadeIn();

    } else {

      $("#go-top").fadeOut();

    }

  });



  $("#go-top").click(function () {

    $("body,html").animate(

      {

        scrollTop: 0,

      },

      800

    );

    return false;

  });



  $(".nav-head").each(function () {

    if ($(this).css("position") === "relative") {

      $(".htagline-title").addClass("smaple");

      $(".htagline-subtitle").addClass("smaple");

    }

  });





});



$(".dropdown-menu a.dropdown-toggle").on("click", function (e) {

  if (!$(this).next().hasClass("show")) {

    $(this).parents(".dropdown-menu").first().find(".show").removeClass("show");

  }

  var $subMenu = $(this).next(".dropdown-menu");

  $subMenu.toggleClass("show");



  $(this)

    .parents("li.nav-item.dropdown.show")

    .on("hidden.bs.dropdown", function (e) {

      $(".dropdown-submenu .show").removeClass("show");

    });



  return false;

});

